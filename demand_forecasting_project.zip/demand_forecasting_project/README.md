\# 📊 Demand Forecasting with Inventory Optimization



\##  Overview

This project develops a machine learning-based demand forecasting system and integrates it with inventory optimization techniques. The goal is to improve prediction accuracy and support better inventory decision-making in retail systems.



The project uses historical sales data to forecast demand and compute inventory policies such as safety stock and reorder points.



\---



\## Features

\- Data preprocessing and feature engineering

\- Time-based and lag-based feature creation

\- Implementation of baseline models:

&#x20; - Naive Forecast

&#x20; - Moving Average

\- Machine learning models:

&#x20; - Linear Regression

&#x20; - Random Forest

\- Model evaluation using MAE, RMSE, and MAPE

\- Inventory optimization:

&#x20; - Safety Stock

&#x20; - Reorder Point

\- Visualization of results



\---



\##  Project Structure



demand\_forecasting\_project/

│

├── data/

│ └── retail\_demand.csv

│

├── src/

│ └── main.py

│

├── outputs/

│ ├── metrics.csv

│ ├── forecasts.csv

│ ├── inventory\_policy\_per\_store.csv

│ ├── forecast\_plot.png

│ └── top\_reorder\_points.png

│

└── README.md





\---



\##  Installation



Make sure you have Python installed (Python 3.8+ recommended).



Install required libraries:



```bash

pip install numpy pandas matplotlib scikit-learn



