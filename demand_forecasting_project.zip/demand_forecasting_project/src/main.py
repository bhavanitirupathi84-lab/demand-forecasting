import os
import warnings
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error

warnings.filterwarnings("ignore")


# =========================================================
# 1. CONFIG
# =========================================================
DATA_PATH = "../data/retail_demand.csv"
OUTPUT_DIR = "../outputs"

os.makedirs(OUTPUT_DIR, exist_ok=True)


# =========================================================
# 2. HELPER FUNCTIONS
# =========================================================
def mape(y_true, y_pred):
    y_true = np.array(y_true)
    y_pred = np.array(y_pred)
    nonzero = y_true != 0
    if nonzero.sum() == 0:
        return np.nan
    return np.mean(np.abs((y_true[nonzero] - y_pred[nonzero]) / y_true[nonzero])) * 100


def create_time_features(df):
    df = df.copy()

    # Walmart dataset dates are like 19-02-2010, so dayfirst=True
    df["date"] = pd.to_datetime(df["date"], dayfirst=True, errors="coerce")
    df = df.dropna(subset=["date"])

    df = df.sort_values(["product_id", "date"])

    df["day_of_week"] = df["date"].dt.dayofweek
    df["month"] = df["date"].dt.month
    df["week_of_year"] = df["date"].dt.isocalendar().week.astype(int)
    df["day_of_month"] = df["date"].dt.day

    return df


def create_lag_features(df, target_col="sales"):
    df = df.copy()
    df = df.sort_values(["product_id", "date"])

    df["lag_1"] = df.groupby("product_id")[target_col].shift(1)
    df["lag_7"] = df.groupby("product_id")[target_col].shift(7)

    df["rolling_mean_7"] = (
        df.groupby("product_id")[target_col]
        .shift(1)
        .rolling(window=7)
        .mean()
        .reset_index(level=0, drop=True)
    )

    df["rolling_std_7"] = (
        df.groupby("product_id")[target_col]
        .shift(1)
        .rolling(window=7)
        .std()
        .reset_index(level=0, drop=True)
    )

    return df


def preprocess_data(df):
    df = df.copy()

    # Standardize column names
    df.columns = [col.strip().lower() for col in df.columns]

    required_cols = {"date", "product_id", "sales"}
    missing = required_cols - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {missing}")

    # Create optional columns if not present
    if "promotion" not in df.columns:
        df["promotion"] = 0

    if "price" not in df.columns:
        df["price"] = 0.0

    if "temperature" not in df.columns:
        df["temperature"] = 0.0

    if "fuel_price" not in df.columns:
        df["fuel_price"] = 0.0

    if "cpi" not in df.columns:
        df["cpi"] = 0.0

    if "unemployment" not in df.columns:
        df["unemployment"] = 0.0

    # Convert numeric columns
    numeric_cols = [
        "sales",
        "price",
        "promotion",
        "temperature",
        "fuel_price",
        "cpi",
        "unemployment"
    ]

    for col in numeric_cols:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    df = df.dropna(subset=["date", "product_id", "sales"])

    # Fill missing values
    for col in ["price", "promotion", "temperature", "fuel_price", "cpi", "unemployment"]:
        if df[col].isna().all():
            df[col] = 0
        else:
            df[col] = df[col].fillna(df[col].median())

    df = create_time_features(df)
    df = create_lag_features(df, target_col="sales")

    # Drop rows lost because of lag features
    df = df.dropna().reset_index(drop=True)

    return df


def train_test_split_time(df, test_ratio=0.2):
    df = df.sort_values("date")
    split_index = int(len(df) * (1 - test_ratio))

    train_df = df.iloc[:split_index].copy()
    test_df = df.iloc[split_index:].copy()

    return train_df, test_df


def evaluate_model(name, y_true, y_pred):
    mae_val = mean_absolute_error(y_true, y_pred)
    rmse_val = np.sqrt(mean_squared_error(y_true, y_pred))
    mape_val = mape(y_true, y_pred)

    return {
        "model": name,
        "MAE": round(mae_val, 4),
        "RMSE": round(rmse_val, 4),
        "MAPE": round(mape_val, 4) if pd.notna(mape_val) else np.nan
    }


def naive_forecast(test_df):
    return test_df["lag_1"].values


def moving_average_forecast(test_df):
    return test_df["rolling_mean_7"].values


def inventory_policy(daily_demand_mean, daily_demand_std, lead_time_days=7,
                     service_z=1.65, order_quantity=100):
    """
    Safety Stock = z * std_demand * sqrt(lead_time)
    Reorder Point = mean_demand * lead_time + safety_stock
    """
    safety_stock = service_z * daily_demand_std * np.sqrt(lead_time_days)
    reorder_point = (daily_demand_mean * lead_time_days) + safety_stock

    return {
        "daily_demand_mean": round(daily_demand_mean, 2),
        "daily_demand_std": round(daily_demand_std, 2),
        "lead_time_days": lead_time_days,
        "service_z": service_z,
        "safety_stock": round(safety_stock, 2),
        "reorder_point": round(reorder_point, 2),
        "order_quantity_q": order_quantity
    }


# =========================================================
# 3. LOAD DATA
# =========================================================
print("Loading dataset...")
raw_df = pd.read_csv(DATA_PATH)
print("Original columns:", raw_df.columns.tolist())

# Rename Walmart dataset columns to match our pipeline
raw_df = raw_df.rename(columns={
    "Date": "date",
    "Weekly_Sales": "sales",
    "Store": "product_id",
    "Holiday_Flag": "promotion",
    "Temperature": "temperature",
    "Fuel_Price": "fuel_price",
    "CPI": "cpi",
    "Unemployment": "unemployment"
})

# Walmart dataset doesn't include product price
raw_df["price"] = 0.0

print("Columns before preprocessing:", raw_df.columns.tolist())

print("Preprocessing data...")
df = preprocess_data(raw_df)

# Convert product_id to numeric
df["product_id"] = pd.to_numeric(df["product_id"], errors="coerce")
df = df.dropna().reset_index(drop=True)

print(f"Processed dataset shape: {df.shape}")
print(df.head())


# =========================================================
# 4. FEATURES
# =========================================================
feature_cols = [
    "product_id",
    "price",
    "promotion",
    "temperature",
    "fuel_price",
    "cpi",
    "unemployment",
    "day_of_week",
    "month",
    "week_of_year",
    "day_of_month",
    "lag_1",
    "lag_7",
    "rolling_mean_7",
    "rolling_std_7"
]

target_col = "sales"

train_df, test_df = train_test_split_time(df, test_ratio=0.2)

X_train = train_df[feature_cols]
y_train = train_df[target_col]

X_test = test_df[feature_cols]
y_test = test_df[target_col]

print(f"Train size: {len(train_df)}, Test size: {len(test_df)}")


# =========================================================
# 5. BASELINE MODELS
# =========================================================
print("Running baseline models...")
naive_pred = naive_forecast(test_df)
ma_pred = moving_average_forecast(test_df)

results = []
results.append(evaluate_model("Naive Forecast", y_test, naive_pred))
results.append(evaluate_model("Moving Average (7)", y_test, ma_pred))


# =========================================================
# 6. MACHINE LEARNING MODELS
# =========================================================
print("Training Linear Regression...")
lr_model = LinearRegression()
lr_model.fit(X_train, y_train)
lr_pred = lr_model.predict(X_test)
results.append(evaluate_model("Linear Regression", y_test, lr_pred))

print("Training Random Forest...")
rf_model = RandomForestRegressor(
    n_estimators=200,
    max_depth=10,
    random_state=42,
    n_jobs=-1
)
rf_model.fit(X_train, y_train)
rf_pred = rf_model.predict(X_test)
results.append(evaluate_model("Random Forest", y_test, rf_pred))


# =========================================================
# 7. SAVE METRICS
# =========================================================
metrics_df = pd.DataFrame(results).sort_values("RMSE")
metrics_path = os.path.join(OUTPUT_DIR, "metrics.csv")
metrics_df.to_csv(metrics_path, index=False)

print("\nModel Performance:")
print(metrics_df)


# =========================================================
# 8. SAVE FORECASTS
# =========================================================
forecast_df = test_df[["date", "product_id", "sales"]].copy()
forecast_df.rename(columns={"sales": "actual_sales"}, inplace=True)

forecast_df["naive_forecast"] = naive_pred
forecast_df["moving_average_7"] = ma_pred
forecast_df["linear_regression"] = lr_pred
forecast_df["random_forest"] = rf_pred

forecast_path = os.path.join(OUTPUT_DIR, "forecasts.csv")
forecast_df.to_csv(forecast_path, index=False)


# =========================================================
# 9. INVENTORY OPTIMIZATION
# =========================================================
print("\nCalculating inventory policy per store...")

# Choose best model
best_model_name = metrics_df.iloc[0]["model"]

if best_model_name == "Naive Forecast":
    forecast_values = naive_pred
elif best_model_name == "Moving Average (7)":
    forecast_values = ma_pred
elif best_model_name == "Linear Regression":
    forecast_values = lr_pred
else:
    forecast_values = rf_pred

# Attach forecast to dataframe
inventory_df = test_df.copy()
inventory_df["forecast"] = forecast_values

# Group by store (product_id)
grouped = inventory_df.groupby("product_id")

inventory_results = []

for product_id, group in grouped:
    daily_mean = group["forecast"].mean()
    daily_std = group["forecast"].std()

    # Inventory formulas
    lead_time = 7
    z = 1.65

    safety_stock = z * daily_std * np.sqrt(lead_time)
    reorder_point = (daily_mean * lead_time) + safety_stock

    inventory_results.append({
        "product_id": product_id,
        "mean_demand": round(daily_mean, 2),
        "std_demand": round(daily_std, 2),
        "safety_stock": round(safety_stock, 2),
        "reorder_point": round(reorder_point, 2)
    })

inventory_policy_df = pd.DataFrame(inventory_results)

policy_path = os.path.join(OUTPUT_DIR, "inventory_policy_per_store.csv")
inventory_policy_df.to_csv(policy_path, index=False)

print("\nInventory Policy (Per Store):")
print(inventory_policy_df.head())


# =========================================================
# 10. PLOT RESULTS
# =========================================================
plt.figure(figsize=(12, 6))
plt.plot(pd.to_datetime(forecast_df["date"]), forecast_df["actual_sales"], label="Actual")
plt.plot(pd.to_datetime(forecast_df["date"]), forecast_df["random_forest"], label="Random Forest")
plt.xticks(rotation=45)
plt.title("Actual vs Forecasted Demand")
plt.xlabel("Date")
plt.ylabel("Sales")
plt.legend()
plt.tight_layout()

plot_path = os.path.join(OUTPUT_DIR, "forecast_plot.png")
plt.savefig(plot_path)
plt.close()

print("\nFiles saved:")
# Plot top 10 stores by reorder point
plt.figure(figsize=(10, 5))

top_reorder_df = inventory_policy_df.sort_values(
    "reorder_point", ascending=False
).head(10)

plt.bar(top_reorder_df["product_id"].astype(str), top_reorder_df["reorder_point"])
plt.title("Top 10 Stores by Reorder Point")
plt.xlabel("Store")
plt.ylabel("Reorder Point")
plt.xticks(rotation=45)
plt.tight_layout()

reorder_plot_path = os.path.join(OUTPUT_DIR, "top_reorder_points.png")
plt.savefig(reorder_plot_path)
plt.close()
print(f"- {metrics_path}")
print(f"- {forecast_path}")
print(f"- {policy_path}")
print(f"- {plot_path}")
print(f"- {reorder_plot_path}")
print("\nProject run completed successfully.")

# =========================================================
# EXTRA: PLOT TOP REORDER POINTS
# =========================================================
plt.figure(figsize=(10,5))

inventory_policy_df.sort_values("reorder_point", ascending=False).head(10).plot(
    x="product_id",
    y="reorder_point",
    kind="bar",
    legend=False
)

plt.title("Top 10 Stores by Reorder Point")
plt.ylabel("Reorder Point")
plt.xlabel("Store")
plt.xticks(rotation=45)
plt.tight_layout()

plt.savefig(os.path.join(OUTPUT_DIR, "top_reorder_points.png"))
plt.close()